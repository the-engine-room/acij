module.exports = (name) => ({ label: name, value: name });
