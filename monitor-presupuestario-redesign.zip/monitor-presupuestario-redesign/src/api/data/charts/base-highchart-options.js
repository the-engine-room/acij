module.exports = {
  chart: {
    height: '500px',
    backgroundColor: 'transparent',
  },
  exporting: {
    enabled: false,
  },
  credits: {
    enabled: false,
  },
  plotOptions: {
    series: {
      animation: false,
      turboThreshold: 0,
    }
  },
  title: null,
  subtitle: null,

};
