/*
MySQL Configuration
 */

module.exports = {
	host     : 'localhost',
	user     : 'root',
	password : 'monitordb',
	database : 'monitor'
};
