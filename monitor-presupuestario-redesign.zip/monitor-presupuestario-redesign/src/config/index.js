const mysqlconfig = require('./mysql');

module.exports = {
  mysqlconfig : { mysqlconfig },
};
