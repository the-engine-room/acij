const ReactGA = require('react-ga');
ReactGA.initialize('UA-149324350-1');

module.exports = ReactGA;
