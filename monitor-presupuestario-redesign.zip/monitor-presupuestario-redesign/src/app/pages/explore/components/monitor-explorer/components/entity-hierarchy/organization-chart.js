let OrganizationChart;
if (global.window) {
  OrganizationChart = require('@dabeng/react-orgchart').default;
}

module.exports = OrganizationChart;
