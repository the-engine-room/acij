const clientInit = require('../../client');
const View = require('./view');

clientInit(View);
