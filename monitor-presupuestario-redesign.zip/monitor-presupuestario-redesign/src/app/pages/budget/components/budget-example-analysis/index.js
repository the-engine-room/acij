const React = require('react');

const BudgetExampleAnalysis = () => (
  <div id="budget-example-analysis">
    <h1>UN EJEMPLO DE ANÁLISIS</h1>
    <div id="budget-example-analysis-video">Video de ejemplo</div>
  </div>
);

module.exports = BudgetExampleAnalysis;
