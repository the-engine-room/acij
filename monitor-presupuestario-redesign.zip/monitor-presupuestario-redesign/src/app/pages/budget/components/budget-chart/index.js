const React = require('react');

const BudgetChart = () => (
  <div style={{
    height: '400px',
    background: '#ccc',
    margin: '30px 0',
    color: '#444',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '3em',
  }}>
    Gráfico
  </div>
);

module.exports = BudgetChart;
